python 3.6.2

#pip install numpy
pip install pandas
pip install jsonschema
pip install requests
pip install flask
pip install pymongo
pip install flask-cors
pip install flask_cache
#pip install virtualenv

ToDo: create package and set paths

+ describe https://confluence.atlassian.com/adminjiraserver071/adding-a-custom-field-802592519.html

